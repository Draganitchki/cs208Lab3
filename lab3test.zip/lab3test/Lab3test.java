/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3test;

/**
 *
 * @author s_draganitchki
 */
public class Lab3test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SingleLinkedList list = new SingleLinkedList();
        
//        list.addFirst(112); 
//        list.addAfter("Joe"); 
//        list.addAfter("Jeff"); 
//        list.addAfter("10"); 
//        list.addAfter("20"); 
//        list.get(0);
        
        
    }
    
}
